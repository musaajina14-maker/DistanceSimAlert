# Distance & SIM Alert V4

Android project for GPS tracking and SIM-alert features.

## GitHub APK build
Open **Actions** in GitHub and run **Build Android APK**. The generated APK is uploaded as an artifact named `DistanceSimAlert-V4-debug`.
