# MUSA AJI — Android App

Owner: **MUSA AJI** · musaajina14@gmail.com

This Android project contains the requested MUSA AJI All-in-One modules:

- Distance / SIM Alert Security
- Photo / PDF Editor
- Photo to Text (OCR)
- Table to Excel foundation
- AI Assistant
- Privacy & Security
- App profile / branding

The supplied MUSA AJI profile photo is included in `app/src/main/res/drawable-nodpi/profile_photo.png` and is used by the app branding screens.

## GitHub Actions APK build

This project is prepared for building from GitHub Actions without Android Studio or a computer.

Workflow: `.github/workflows/android-build.yml`

It:
1. Checks out the repository.
2. Sets up JDK 17.
3. Sets up the Android SDK.
4. Installs Gradle 8.7 through the official Gradle GitHub Action.
5. Runs `gradle assembleDebug`.
6. Uploads the APK as `musa-aji-debug-apk`.

**Important:** this ZIP intentionally does not require a pre-committed `gradlew` file. The workflow invokes Gradle 8.7 directly, avoiding the earlier `gradlew: No such file or directory` failure.

### Repository layout

When uploading to GitHub, the files below must be at the repository root:

- `app/`
- `gradle/`
- `.github/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`

Do not put the project inside an extra nested folder in the GitHub repository.

### Build

After the project is pushed to a repository, open **Actions → Build MUSA AJI APK → Run workflow**. When the run succeeds, download the `musa-aji-debug-apk` artifact.

## Android limitations

The security module uses Android-supported permissions and APIs. Android does not allow an ordinary app to silently bypass the lock screen, capture another person's unlock attempt without OS support, or reveal the exact replacement SIM subscriber information without the required carrier/system privileges. The project therefore does not claim to implement those restricted behaviors.
