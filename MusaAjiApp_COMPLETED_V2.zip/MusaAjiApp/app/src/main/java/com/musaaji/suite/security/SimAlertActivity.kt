package com.musaaji.suite.security

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import com.musaaji.suite.R
import com.musaaji.suite.common.PermissionUtils
import com.musaaji.suite.common.SecurePrefs
import com.musaaji.suite.databinding.ActivitySimAlertBinding

class SimAlertActivity : AppCompatActivity() {

    companion object {
        const val PREF_SIM_MONITOR_ON = "sim_monitor_on"
        const val PREF_DISTANCE_MONITOR_ON = "distance_monitor_on"
        const val PREF_HOME_LAT = "home_lat"
        const val PREF_HOME_LNG = "home_lng"
        const val PREF_RADIUS_M = "radius_m"
    }

    private lateinit var binding: ActivitySimAlertBinding

    private val requestPhoneStatePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            setSimMonitor(true)
        } else {
            binding.switchSimMonitor.isChecked = false
            Toast.makeText(this, "READ_PHONE_STATE was denied — SIM alerts stay off.", Toast.LENGTH_LONG).show()
        }
    }

    private val requestLocationPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        if (granted) captureHomePoint() else
            Toast.makeText(this, "Location permission denied — cannot set a home point.", Toast.LENGTH_LONG).show()
    }

    private val requestDistanceMonitorPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        if (granted) {
            startDistanceService()
        } else {
            binding.switchDistanceMonitor.isChecked = false
            Toast.makeText(this, "Location permission denied — distance monitoring stays off.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySimAlertBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_sim_alert)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val prefs = SecurePrefs.get(this)

        binding.switchSimMonitor.isChecked = prefs.getBoolean(PREF_SIM_MONITOR_ON, false)
        binding.switchDistanceMonitor.isChecked = prefs.getBoolean(PREF_DISTANCE_MONITOR_ON, false)
        binding.editRadius.setText(prefs.getInt(PREF_RADIUS_M, 500).toString())
        updateSimStatusText()
        updateHomePointText()

        binding.switchSimMonitor.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (PermissionUtils.hasPermission(this, Manifest.permission.READ_PHONE_STATE)) {
                    setSimMonitor(true)
                } else {
                    requestPhoneStatePermission.launch(Manifest.permission.READ_PHONE_STATE)
                }
            } else {
                setSimMonitor(false)
            }
        }

        binding.btnSetHome.setOnClickListener {
            if (PermissionUtils.hasAny(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            ) {
                captureHomePoint()
            } else {
                requestLocationPermissions.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }

        binding.switchDistanceMonitor.setOnCheckedChangeListener { _, isChecked ->
            val radius = binding.editRadius.text.toString().toIntOrNull() ?: 500
            SecurePrefs.get(this).edit().putInt(PREF_RADIUS_M, radius).apply()

            if (isChecked) {
                val hasHome = SecurePrefs.get(this).contains(PREF_HOME_LAT)
                if (!hasHome) {
                    Toast.makeText(this, "Set a home point first.", Toast.LENGTH_LONG).show()
                    binding.switchDistanceMonitor.isChecked = false
                    return@setOnCheckedChangeListener
                }
                if (PermissionUtils.hasAny(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                ) {
                    startDistanceService()
                } else {
                    requestDistanceMonitorPermissions.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            } else {
                stopDistanceService()
            }
        }

        binding.txtLimitations.text = """
            Platform limitations (by Android design, not a bug in this app):
            • The app can detect that the SIM state changed, but Android does not expose which SIM/subscriber replaced it to non-carrier-privileged apps.
            • Continuous background location requires a visible foreground-service notification (shown above when monitoring is on) — Android does not allow silent background tracking.
            • On Android 10+, always-on background location needs a separate "Allow all the time" grant in system Settings.
            • The OS may delay or batch location updates to save battery; this is expected behavior.
        """.trimIndent()
    }

    private fun setSimMonitor(on: Boolean) {
        SecurePrefs.get(this).edit().putBoolean(PREF_SIM_MONITOR_ON, on).apply()
        binding.switchSimMonitor.isChecked = on
        updateSimStatusText()
    }

    private fun updateSimStatusText() {
        val on = SecurePrefs.get(this).getBoolean(PREF_SIM_MONITOR_ON, false)
        binding.txtSimStatus.text = if (on)
            "Monitoring is ON. You'll get a notification if the system reports a SIM state change."
        else
            "Monitoring is OFF."
    }

    private fun captureHomePoint() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) {
            try {
                val loc = lm.getLastKnownLocation(p) ?: continue
                if (best == null || loc.accuracy < best!!.accuracy) best = loc
            } catch (e: SecurityException) {
                // Permission revoked between the check above and this call — ignore this provider.
            }
        }
        if (best != null) {
            saveHomePoint(best)
            return
        }
        // No cached fix yet — request a single fresh update.
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    saveHomePoint(location)
                    lm.removeUpdates(this)
                }
            }
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            lm.requestSingleUpdate(provider, listener, mainLooper)
            Toast.makeText(this, "Getting a location fix…", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Location permission not granted.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveHomePoint(location: Location) {
        SecurePrefs.get(this).edit()
            .putFloat(PREF_HOME_LAT, location.latitude.toFloat())
            .putFloat(PREF_HOME_LNG, location.longitude.toFloat())
            .apply()
        updateHomePointText()
        Toast.makeText(this, "Home point saved.", Toast.LENGTH_SHORT).show()
    }

    private fun updateHomePointText() {
        val prefs = SecurePrefs.get(this)
        if (prefs.contains(PREF_HOME_LAT)) {
            val lat = prefs.getFloat(PREF_HOME_LAT, 0f)
            val lng = prefs.getFloat(PREF_HOME_LNG, 0f)
            binding.txtHomePoint.text = "Home point: %.5f, %.5f".format(lat, lng)
        } else {
            binding.txtHomePoint.text = "Home point: not set"
        }
    }

    private fun startDistanceService() {
        val radius = binding.editRadius.text.toString().toIntOrNull() ?: 500
        SecurePrefs.get(this).edit()
            .putInt(PREF_RADIUS_M, radius)
            .putBoolean(PREF_DISTANCE_MONITOR_ON, true)
            .apply()
        val intent = Intent(this, DistanceMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopDistanceService() {
        SecurePrefs.get(this).edit().putBoolean(PREF_DISTANCE_MONITOR_ON, false).apply()
        stopService(Intent(this, DistanceMonitorService::class.java))
    }
}
