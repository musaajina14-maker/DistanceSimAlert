package com.musaaji.suite.security

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.musaaji.suite.MainActivity
import com.musaaji.suite.MusaAjiApplication
import com.musaaji.suite.R
import com.musaaji.suite.common.SecurePrefs

/**
 * Foreground service that watches the device's distance from a saved "home"
 * point using the plain android.location.LocationManager API (no Play
 * Services dependency required).
 *
 * ANDROID LIMITATIONS this module respects rather than works around:
 *  - Since Android 8 (Oreo), apps cannot receive location updates in the
 *    background except through a foreground service with an ongoing
 *    notification (which this service shows) — silent background tracking
 *    is not permitted.
 *  - Since Android 10, continuous background location additionally requires
 *    ACCESS_BACKGROUND_LOCATION, granted separately by the user in system
 *    Settings — it cannot be requested in the same runtime prompt as
 *    foreground location.
 *  - Since Android 12, apps can only request ACCESS_COARSE_LOCATION and the
 *    user may deny ACCESS_FINE_LOCATION while still allowing coarse; this
 *    module works with whichever the user grants, at reduced accuracy.
 *  - The OS may still throttle or batch updates for battery reasons; this is
 *    expected platform behavior, not a bug.
 */
class DistanceMonitorService : Service() {

    private lateinit var locationManager: LocationManager
    private var homeLat = 0.0
    private var homeLng = 0.0
    private var radiusMeters = 500f

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            checkDistance(location)
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = SecurePrefs.get(this)
        homeLat = prefs.getFloat(SimAlertActivity.PREF_HOME_LAT, 0f).toDouble()
        homeLng = prefs.getFloat(SimAlertActivity.PREF_HOME_LNG, 0f).toDouble()
        radiusMeters = prefs.getInt(SimAlertActivity.PREF_RADIUS_M, 500)

        startForeground(2001, buildOngoingNotification())

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 30_000L, 25f, listener
                )
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER, 30_000L, 25f, listener
                )
            } catch (e: SecurityException) {
                stopSelf()
            } catch (e: IllegalArgumentException) {
                // Provider not available on this device (e.g. no GPS hardware) — expected on some devices.
            }
        } else {
            stopSelf()
        }
        return START_STICKY
    }

    private fun checkDistance(location: Location) {
        val home = Location("home").apply {
            latitude = homeLat
            longitude = homeLng
        }
        val distance = home.distanceTo(location)
        if (distance > radiusMeters) {
            sendDistanceAlert(distance)
        }
    }

    private fun sendDistanceAlert(distance: Float) {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, MusaAjiApplication.CHANNEL_SECURITY)
            .setSmallIcon(R.drawable.ic_module_generic)
            .setContentTitle("Distance alert")
            .setContentText("Device is now ${distance.toInt()} m from the home point (limit ${radiusMeters.toInt()} m).")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        NotificationManagerCompat.from(this).notify(2002, notification)
    }

    private fun buildOngoingNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, MusaAjiApplication.CHANNEL_SECURITY)
            .setSmallIcon(R.drawable.ic_module_generic)
            .setContentTitle("Distance monitoring active")
            .setContentText("MUSA AJI is watching distance from your home point.")
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            locationManager.removeUpdates(listener)
        } catch (e: SecurityException) {
            // Permission may have been revoked between requestLocationUpdates and removeUpdates.
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
