package com.musaaji.suite.privacy

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.musaaji.suite.R
import com.musaaji.suite.common.PermissionUtils
import com.musaaji.suite.common.SecurePrefs
import com.musaaji.suite.databinding.ActivityPrivacySecurityBinding

class PrivacySecurityActivity : AppCompatActivity() {

    companion object {
        private const val PREF_APP_LOCK_ON = "app_lock_on"

        fun isAppLockEnabled(context: android.content.Context): Boolean =
            SecurePrefs.get(context).getBoolean(PREF_APP_LOCK_ON, false)
    }

    private lateinit var binding: ActivityPrivacySecurityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacySecurityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_privacy)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val prefs = SecurePrefs.get(this)
        binding.switchAppLock.isChecked = prefs.getBoolean(PREF_APP_LOCK_ON, false)
        binding.switchAppLock.setOnCheckedChangeListener { _, isChecked ->
            val canUseBiometric = BiometricSupport.canAuthenticate(this)
            if (isChecked && !canUseBiometric) {
                binding.switchAppLock.isChecked = false
                Toast.makeText(
                    this,
                    "No device screen lock / biometric is set up. Set one in system Settings first.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnCheckedChangeListener
            }
            prefs.edit().putBoolean(PREF_APP_LOCK_ON, isChecked).apply()
        }

        binding.btnWipeSecureData.setOnClickListener { confirmWipe() }

        loadPermissions()

        binding.txtLimitations.text = """
            Platform limitations (by Android design, not a bug in this app):
            • App Lock uses BiometricPrompt, which only reports success/failure — this app never receives fingerprint or face data itself; Android's secure hardware handles matching.
            • Every permission above must be granted by you individually; this app cannot silently enable a permission for itself.
            • On Android 11+, if you deny a permission twice the system may require you to enable it from system Settings instead of the in-app prompt.
            • Data placed in EncryptedSharedPreferences is protected on-device, but a rooted device or a backup made outside Android's official mechanisms is outside what any app-level encryption can guarantee.
        """.trimIndent()
    }

    private fun confirmWipe() {
        AlertDialog.Builder(this)
            .setTitle("Wipe encrypted app data?")
            .setMessage("This clears the AI Assistant key, saved home point, and app-lock setting stored on this device. This cannot be undone.")
            .setPositiveButton("Wipe") { _, _ ->
                SecurePrefs.get(this).edit().clear().apply()
                binding.switchAppLock.isChecked = false
                Toast.makeText(this, "Encrypted data wiped.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadPermissions()
    }

    private fun loadPermissions() {
        val rows = mutableListOf(
            PermissionRow("Phone state (SIM alert)", Manifest.permission.READ_PHONE_STATE,
                PermissionUtils.hasPermission(this, Manifest.permission.READ_PHONE_STATE)),
            PermissionRow("Location (Distance alert)", Manifest.permission.ACCESS_FINE_LOCATION,
                PermissionUtils.hasAny(this, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)),
            PermissionRow("Photos (Editor/OCR)", Manifest.permission.READ_MEDIA_IMAGES,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    PermissionUtils.hasPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                else true)
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            rows.add(
                PermissionRow("Notifications (Alerts)", Manifest.permission.POST_NOTIFICATIONS,
                    PermissionUtils.hasPermission(this, Manifest.permission.POST_NOTIFICATIONS))
            )
        }

        binding.recyclerPermissions.layoutManager = LinearLayoutManager(this)
        binding.recyclerPermissions.adapter = PermissionAdapter(rows) { openAppSettings() }
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }
}
