package com.musaaji.suite.common

data class ModuleItem(
    val title: String,
    val iconRes: Int,
    val onClick: () -> Unit
)
