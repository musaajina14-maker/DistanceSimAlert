package com.musaaji.suite

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class MusaAjiApplication : Application() {

    companion object {
        const val CHANNEL_SECURITY = "musaaji_security_alerts"
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_SECURITY,
                "Security alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "SIM change and distance alerts from the Security module"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }
}
