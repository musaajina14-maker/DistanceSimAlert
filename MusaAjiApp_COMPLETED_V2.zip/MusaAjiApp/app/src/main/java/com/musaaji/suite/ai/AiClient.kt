package com.musaaji.suite.ai

import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Thin, provider-agnostic HTTP client for the AI Assistant module.
 *
 * No API key or endpoint is bundled with this app. The user supplies both in
 * Settings (stored only in EncryptedSharedPreferences, see SecurePrefs). This
 * client sends both an "Authorization: Bearer" header and an "x-api-key"
 * header so it works against most REST-style chat-completion APIs without
 * per-provider code branches; unused headers are simply ignored by the
 * receiving API.
 */
object AiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun sendMessage(
        endpoint: String,
        apiKey: String,
        model: String,
        userMessage: String,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val body = JSONObject().apply {
            put("model", model.ifBlank { "claude-sonnet-4-6" })
            put("max_tokens", 1024)
            put("messages", JSONArray().put(
                JSONObject().put("role", "user").put("content", userMessage)
            ))
        }

        val isAnthropic = endpoint.contains("anthropic.com", ignoreCase = true)
        val requestBuilder = Request.Builder()
            .url(endpoint)
            .addHeader("Content-Type", "application/json")
        if (isAnthropic) {
            requestBuilder.addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
        } else {
            requestBuilder.addHeader("Authorization", "Bearer $apiKey")
        }
        val request = requestBuilder
            .post(body.toString().toRequestBody(JSON))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onError(e.message ?: "Network error")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    if (!it.isSuccessful) {
                        onError("HTTP ${it.code}: ${raw.take(300)}")
                        return
                    }
                    onResult(extractText(raw))
                }
            }
        })
    }

    /** Leniently pulls a reply string out of a few common response shapes. */
    private fun extractText(raw: String): String {
        return try {
            val json = JSONObject(raw)
            when {
                json.has("content") -> {
                    val content = json.optJSONArray("content")
                    val sb = StringBuilder()
                    if (content != null) {
                        for (i in 0 until content.length()) {
                            val block = content.optJSONObject(i)
                            if (block?.optString("type") == "text") sb.append(block.optString("text"))
                        }
                    }
                    if (sb.isNotEmpty()) sb.toString() else raw
                }
                json.has("choices") -> {
                    val choices = json.optJSONArray("choices")
                    val first = choices?.optJSONObject(0)
                    first?.optJSONObject("message")?.optString("content")
                        ?.takeIf { it.isNotBlank() }
                        ?: first?.optString("text")?.takeIf { it.isNotBlank() }
                        ?: raw
                }
                json.has("output_text") -> json.optString("output_text", raw)
                json.has("error") -> json.optJSONObject("error")?.optString("message", raw) ?: raw
                else -> raw
            }
        } catch (e: Exception) {
            raw
        }
    }
}
