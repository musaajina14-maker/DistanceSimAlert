package com.musaaji.suite.common

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object PermissionUtils {

    fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasAny(context: Context, vararg permissions: String): Boolean =
        permissions.any { hasPermission(context, it) }

    fun hasAll(context: Context, vararg permissions: String): Boolean =
        permissions.all { hasPermission(context, it) }
}
