package com.musaaji.suite.common

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.musaaji.suite.databinding.ItemModuleBinding

class ModuleAdapter(private val items: List<ModuleItem>) :
    RecyclerView.Adapter<ModuleAdapter.ModuleViewHolder>() {

    inner class ModuleViewHolder(val binding: ItemModuleBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ModuleViewHolder {
        val binding = ItemModuleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ModuleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ModuleViewHolder, position: Int) {
        val item = items[position]
        holder.binding.txtTitle.text = item.title
        holder.binding.imgIcon.setImageResource(item.iconRes)
        holder.binding.root.setOnClickListener { item.onClick() }
    }

    override fun getItemCount(): Int = items.size
}
