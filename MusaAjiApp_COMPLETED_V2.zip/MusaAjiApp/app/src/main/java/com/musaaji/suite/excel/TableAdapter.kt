package com.musaaji.suite.excel

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.musaaji.suite.R

/**
 * Renders an editable spreadsheet-like grid. [data] is a mutable list of rows,
 * each row a mutable list of cell strings. The adapter keeps [data] in sync
 * with what the user types, so the caller can export it at any time.
 */
class TableAdapter(private val data: MutableList<MutableList<String>>) :
    RecyclerView.Adapter<TableAdapter.RowViewHolder>() {

    inner class RowViewHolder(val container: android.widget.LinearLayout) :
        RecyclerView.ViewHolder(container)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_table_row, parent, false) as android.widget.LinearLayout
        return RowViewHolder(view)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val row = data[position]
        holder.container.removeAllViews()
        val inflater = LayoutInflater.from(holder.container.context)

        for (colIndex in row.indices) {
            val cell = inflater.inflate(R.layout.cell_edit_text, holder.container, false) as EditText
            cell.setText(row[colIndex])
            cell.tag = null // prevent stale watcher firing during recycle, set below
            cell.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val adapterPos = holder.bindingAdapterPosition
                    if (adapterPos != RecyclerView.NO_POSITION && colIndex < data[adapterPos].size) {
                        data[adapterPos][colIndex] = s?.toString() ?: ""
                    }
                }
            })
            holder.container.addView(cell)
        }
    }

    override fun getItemCount(): Int = data.size

    fun addRow(columnCount: Int) {
        data.add(MutableList(columnCount) { "" })
        notifyItemInserted(data.size - 1)
    }

    fun addColumn() {
        for (row in data) row.add("")
        notifyDataSetChanged()
    }
}
