package com.musaaji.suite.privacy

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.musaaji.suite.databinding.ItemPermissionBinding

class PermissionAdapter(
    private val rows: List<PermissionRow>,
    private val onManage: (PermissionRow) -> Unit
) : RecyclerView.Adapter<PermissionAdapter.RowViewHolder>() {

    inner class RowViewHolder(val binding: ItemPermissionBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val binding = ItemPermissionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RowViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val row = rows[position]
        holder.binding.txtPermName.text = row.label
        holder.binding.txtPermState.text = if (row.granted) "Granted" else "Not granted"
        holder.binding.btnPermAction.setOnClickListener { onManage(row) }
    }

    override fun getItemCount(): Int = rows.size
}
