package com.musaaji.suite.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.musaaji.suite.R
import com.musaaji.suite.common.SecurePrefs
import com.musaaji.suite.databinding.ActivityAiAssistantBinding
import com.musaaji.suite.databinding.DialogAiSettingsBinding

class AiAssistantActivity : AppCompatActivity() {

    companion object {
        private const val PREF_ENDPOINT = "ai_endpoint"
        private const val PREF_API_KEY = "ai_api_key"
        private const val PREF_MODEL = "ai_model"
        private const val DEFAULT_MODEL = "claude-sonnet-4-6"
        private const val DEFAULT_ENDPOINT = "https://api.anthropic.com/v1/messages"
    }

    private lateinit var binding: ActivityAiAssistantBinding
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAiAssistantBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_ai)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ChatAdapter(messages)
        binding.recyclerChat.layoutManager = LinearLayoutManager(this)
        binding.recyclerChat.adapter = adapter

        binding.btnSettings.setOnClickListener { showSettingsDialog() }
        binding.btnSend.setOnClickListener { sendMessage() }
    }

    private fun showSettingsDialog() {
        val dialogBinding = DialogAiSettingsBinding.inflate(LayoutInflater.from(this))
        val prefs = SecurePrefs.get(this)
        dialogBinding.editEndpoint.setText(prefs.getString(PREF_ENDPOINT, DEFAULT_ENDPOINT))
        dialogBinding.editApiKey.setText(prefs.getString(PREF_API_KEY, ""))
        dialogBinding.editModel.setText(prefs.getString(PREF_MODEL, DEFAULT_MODEL))

        AlertDialog.Builder(this)
            .setTitle("AI Assistant settings")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString(PREF_ENDPOINT, dialogBinding.editEndpoint.text.toString().ifBlank { DEFAULT_ENDPOINT })
                    .putString(PREF_API_KEY, dialogBinding.editApiKey.text.toString().trim())
                    .putString(PREF_MODEL, dialogBinding.editModel.text.toString().trim().ifBlank { DEFAULT_MODEL })
                    .apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendMessage() {
        val text = binding.editMessage.text.toString().trim()
        if (text.isBlank()) return
        binding.editMessage.setText("")
        adapter.addMessage(ChatMessage("You", text, true))
        binding.recyclerChat.scrollToPosition(messages.size - 1)

        val prefs = SecurePrefs.get(this)
        val endpoint = prefs.getString(PREF_ENDPOINT, DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT
        val apiKey = prefs.getString(PREF_API_KEY, "") ?: ""
        val model = prefs.getString(PREF_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL

        if (apiKey.isBlank()) {
            adapter.addMessage(ChatMessage("MUSA AJI", "No API key set yet. Tap Settings above and add your key first.", false))
            return
        }

        binding.progress.visibility = View.VISIBLE
        binding.btnSend.isEnabled = false

        AiClient.sendMessage(
            endpoint, apiKey, model, text,
            onResult = { reply ->
                runOnUiThread {
                    binding.progress.visibility = View.GONE
                    binding.btnSend.isEnabled = true
                    adapter.addMessage(ChatMessage("MUSA AJI", reply, false))
                    binding.recyclerChat.scrollToPosition(messages.size - 1)
                }
            },
            onError = { error ->
                runOnUiThread {
                    binding.progress.visibility = View.GONE
                    binding.btnSend.isEnabled = true
                    adapter.addMessage(ChatMessage("MUSA AJI", "Error: $error", false))
                }
            }
        )
    }
}
