package com.musaaji.suite.common

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wrapper around androidx.security EncryptedSharedPreferences.
 * Backed by an AES-256 key stored in the Android Keystore, so the key never
 * exists as plain bytes outside secure hardware/software storage.
 * Used to hold: the AI Assistant endpoint/API key, the home-point coordinates
 * for the distance alert, and the app-lock on/off flag.
 */
object SecurePrefs {

    private const val FILE_NAME = "secure_prefs"

    private var cached: SharedPreferences? = null

    fun get(context: Context): SharedPreferences {
        cached?.let { return it }
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val prefs = EncryptedSharedPreferences.create(
            context.applicationContext,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        cached = prefs
        return prefs
    }
}
