package com.musaaji.suite.ocr

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.musaaji.suite.R
import com.musaaji.suite.databinding.ActivityOcrBinding

/**
 * On-device OCR using ML Kit Text Recognition. The recognition model runs
 * locally on the device — the image is never uploaded anywhere.
 */
class OcrActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOcrBinding
    private var pickedUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            pickedUri = it
            binding.imgPreview.setImageURI(it)
            binding.btnRun.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOcrBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_ocr)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnPick.setOnClickListener { pickImage.launch("image/*") }
        binding.btnRun.setOnClickListener { runOcr() }
        binding.btnCopy.setOnClickListener { copyText() }
    }

    private fun runOcr() {
        val uri = pickedUri ?: return
        binding.progress.visibility = View.VISIBLE
        binding.btnRun.isEnabled = false
        try {
            val stream = contentResolver.openInputStream(uri) ?: return
            val bitmap = BitmapFactory.decodeStream(stream)
            stream.close()
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    binding.progress.visibility = View.GONE
                    binding.btnRun.isEnabled = true
                    val text = visionText.text
                    binding.txtResult.text = text.ifBlank { "No text detected in this image." }
                    binding.btnCopy.isEnabled = text.isNotBlank()
                }
                .addOnFailureListener { e ->
                    binding.progress.visibility = View.GONE
                    binding.btnRun.isEnabled = true
                    Toast.makeText(this, "OCR failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
        } catch (e: Exception) {
            binding.progress.visibility = View.GONE
            binding.btnRun.isEnabled = true
            Toast.makeText(this, "Could not read image: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun copyText() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("OCR text", binding.txtResult.text))
        Toast.makeText(this, "Copied to clipboard.", Toast.LENGTH_SHORT).show()
    }
}
