package com.musaaji.suite

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.musaaji.suite.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.title = getString(R.string.module_about)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "1.0.0"
        }
        binding.txtVersion.text = "Version $versionName"
        // binding.imgProfile shows the real MUSA AJI profile photo
        // (res/drawable-nodpi/profile_photo.png), set directly in the layout.
    }
}
