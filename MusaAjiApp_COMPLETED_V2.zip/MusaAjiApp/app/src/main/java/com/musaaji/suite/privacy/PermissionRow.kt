package com.musaaji.suite.privacy

data class PermissionRow(val label: String, val permission: String, val granted: Boolean)
