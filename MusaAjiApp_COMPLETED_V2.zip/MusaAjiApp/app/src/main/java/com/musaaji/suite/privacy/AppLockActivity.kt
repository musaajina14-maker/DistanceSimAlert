package com.musaaji.suite.privacy

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.musaaji.suite.databinding.ActivityAppLockBinding

/**
 * Shown on top of MainActivity when App Lock is enabled. Uses
 * androidx.biometric.BiometricPrompt, the Android-supported way to gate
 * access behind the device's own fingerprint/face/PIN/pattern check.
 * This app never sees the biometric data itself — only a success/failure
 * callback from the OS.
 */
class AppLockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppLockBinding
    private lateinit var biometricPrompt: BiometricPrompt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                finish()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                Toast.makeText(this@AppLockActivity, "Unlock cancelled: $errString", Toast.LENGTH_SHORT).show()
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock MUSA AJI")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        binding.btnUnlock.setOnClickListener { biometricPrompt.authenticate(promptInfo) }
        biometricPrompt.authenticate(promptInfo)
    }

    override fun onBackPressed() {
        // Block back-button bypass — the user must authenticate or leave the app.
        moveTaskToBack(true)
    }
}
