package com.musaaji.suite.excel

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.musaaji.suite.R
import com.musaaji.suite.databinding.ActivityTableToExcelBinding
import android.provider.MediaStore

class TableToExcelActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTableToExcelBinding
    private lateinit var adapter: TableAdapter
    private val data: MutableList<MutableList<String>> = mutableListOf(
        mutableListOf("Item", "Qty", "Price"),
        mutableListOf("", "", "")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTableToExcelBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_excel)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = TableAdapter(data)
        binding.recyclerTable.layoutManager = LinearLayoutManager(this)
        binding.recyclerTable.adapter = adapter

        binding.btnAddRow.setOnClickListener {
            val colCount = data.firstOrNull()?.size ?: 1
            adapter.addRow(colCount)
        }
        binding.btnAddCol.setOnClickListener { adapter.addColumn() }
        binding.btnExport.setOnClickListener { exportToXlsx() }
    }

    private fun exportToXlsx() {
        val fileName = "MusaAji_Table_${System.currentTimeMillis()}.xlsx"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/MusaAji")
                }
                val uri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { os ->
                        XlsxWriter.write(os, "Sheet1", data)
                    }
                }
            } else {
                val dir = getExternalFilesDir(null)
                val file = java.io.File(dir, fileName)
                java.io.FileOutputStream(file).use { XlsxWriter.write(it, "Sheet1", data) }
            }
            Toast.makeText(this, "Exported: $fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
