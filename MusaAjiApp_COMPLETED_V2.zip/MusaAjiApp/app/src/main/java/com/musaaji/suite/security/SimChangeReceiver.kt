package com.musaaji.suite.security

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import com.musaaji.suite.MainActivity
import com.musaaji.suite.MusaAjiApplication
import com.musaaji.suite.R
import com.musaaji.suite.common.SecurePrefs

/**
 * Listens for the system-wide android.intent.action.SIM_STATE_CHANGED broadcast.
 *
 * ANDROID LIMITATION: apps cannot be told *which* SIM was swapped in/out, only
 * that the SIM state changed (e.g. ABSENT, READY, LOCKED). Reading the SIM
 * serial/subscriber ID requires READ_PHONE_STATE (and on Android 10+,
 * READ_PHONE_NUMBERS / carrier privileges for some fields), and even then
 * some values are blocked entirely by policy on non-carrier-privileged apps.
 * This receiver reports a change occurred; it does not attempt to defeat
 * those restrictions.
 */
class SimChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_SIM_CARD_STATE_CHANGED &&
            intent.action != "android.intent.action.SIM_STATE_CHANGED"
        ) return

        val prefs = SecurePrefs.get(context)
        if (!prefs.getBoolean(SimAlertActivity.PREF_SIM_MONITOR_ON, false)) return

        notifyUser(context)
    }

    private fun notifyUser(context: Context) {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED &&
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU
        ) {
            return
        }

        val openIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = android.app.PendingIntent.getActivity(
            context, 0, openIntent,
            android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MusaAjiApplication.CHANNEL_SECURITY)
            .setSmallIcon(R.drawable.ic_module_generic)
            .setContentTitle("SIM state changed")
            .setContentText("Your device reported a SIM card state change.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(1001, notification)
    }
}
