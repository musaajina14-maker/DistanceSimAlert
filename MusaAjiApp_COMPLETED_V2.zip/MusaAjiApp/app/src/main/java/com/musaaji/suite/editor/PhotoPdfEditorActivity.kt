package com.musaaji.suite.editor

import android.content.ContentValues
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.musaaji.suite.R
import com.musaaji.suite.databinding.ActivityPhotoPdfEditorBinding
import java.io.OutputStream

/**
 * Simple photo editor (rotate + text markup) and PDF exporter.
 * Uses only built-in Android APIs:
 *  - androidx Photo Picker (ACTION_PICK_IMAGES / GetContent) for image selection,
 *    which needs no storage permission on Android 13+ and works down-level too.
 *  - android.graphics.pdf.PdfDocument to build the PDF (part of the SDK).
 *  - MediaStore to save output without needing broad storage permissions.
 */
class PhotoPdfEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoPdfEditorBinding
    private var currentBitmap: Bitmap? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { loadImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoPdfEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.module_photo_pdf)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnPick.setOnClickListener { pickImage.launch("image/*") }

        binding.btnRotate.setOnClickListener {
            currentBitmap?.let {
                val matrix = Matrix().apply { postRotate(90f) }
                val rotated = Bitmap.createBitmap(it, 0, 0, it.width, it.height, matrix, true)
                currentBitmap = rotated
                binding.imgPreview.setImageBitmap(rotated)
            }
        }

        binding.btnMarkup.setOnClickListener { showMarkupDialog() }
        binding.btnExportPdf.setOnClickListener { exportAsPdf() }
        binding.btnExportPng.setOnClickListener { saveEditedPhoto() }
    }

    private fun loadImage(uri: Uri) {
        val stream = contentResolver.openInputStream(uri) ?: return
        val bitmap = BitmapFactory.decodeStream(stream)
        stream.close()
        currentBitmap = bitmap
        binding.imgPreview.setImageBitmap(bitmap)
        setButtonsEnabled(true)
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        binding.btnRotate.isEnabled = enabled
        binding.btnMarkup.isEnabled = enabled
        binding.btnExportPdf.isEnabled = enabled
        binding.btnExportPng.isEnabled = enabled
    }

    private fun showMarkupDialog() {
        val input = EditText(this).apply { hint = "Text to stamp on the photo" }
        AlertDialog.Builder(this)
            .setTitle("Add text mark")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString()
                if (text.isNotBlank()) stampText(text)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun stampText(text: String) {
        val src = currentBitmap ?: return
        val mutable = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutable)
        val paint = Paint().apply {
            color = Color.YELLOW
            textSize = mutable.width * 0.05f
            isAntiAlias = true
            setShadowLayer(6f, 2f, 2f, Color.BLACK)
        }
        canvas.drawText(text, mutable.width * 0.05f, mutable.height * 0.92f, paint)
        currentBitmap = mutable
        binding.imgPreview.setImageBitmap(mutable)
    }

    private fun exportAsPdf() {
        val bitmap = currentBitmap ?: return
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
        val page = document.startPage(pageInfo)
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)
        document.finishPage(page)

        val fileName = "MusaAji_${System.currentTimeMillis()}.pdf"
        val outputStream: OutputStream?
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/MusaAji")
                }
                val uri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                outputStream = uri?.let { contentResolver.openOutputStream(it) }
            } else {
                val dir = getExternalFilesDir(null)
                val file = java.io.File(dir, fileName)
                outputStream = java.io.FileOutputStream(file)
            }
            outputStream?.use { document.writeTo(it) }
            Toast.makeText(this, "Saved: $fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun saveEditedPhoto() {
        val bitmap = currentBitmap ?: return
        val fileName = "MusaAji_${System.currentTimeMillis()}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MusaAji")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let { contentResolver.openOutputStream(it)?.use { os -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, os) } }
            } else {
                val dir = getExternalFilesDir(null)
                val file = java.io.File(dir, fileName)
                java.io.FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            Toast.makeText(this, "Saved: $fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
