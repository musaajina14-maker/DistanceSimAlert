package com.musaaji.suite.ai

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)
