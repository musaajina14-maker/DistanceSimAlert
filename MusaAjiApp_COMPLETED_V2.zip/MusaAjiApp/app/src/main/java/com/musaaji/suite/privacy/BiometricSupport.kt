package com.musaaji.suite.privacy

import android.content.Context
import androidx.biometric.BiometricManager

object BiometricSupport {

    /**
     * True only if the device currently has a usable biometric or device
     * credential (PIN/pattern/password) enrolled. BIOMETRIC_WEAK covers
     * fingerprint/face; DEVICE_CREDENTIAL covers PIN/pattern/password as a
     * fallback — both are standard Android-supported authenticator types.
     */
    fun canAuthenticate(context: Context): Boolean {
        val manager = BiometricManager.from(context)
        val result = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }
}
