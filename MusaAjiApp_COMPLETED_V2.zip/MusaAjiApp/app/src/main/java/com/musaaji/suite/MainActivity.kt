package com.musaaji.suite

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.musaaji.suite.ai.AiAssistantActivity
import com.musaaji.suite.common.ModuleAdapter
import com.musaaji.suite.common.ModuleItem
import com.musaaji.suite.databinding.ActivityMainBinding
import com.musaaji.suite.editor.PhotoPdfEditorActivity
import com.musaaji.suite.excel.TableToExcelActivity
import com.musaaji.suite.ocr.OcrActivity
import com.musaaji.suite.privacy.AppLockActivity
import com.musaaji.suite.privacy.PrivacySecurityActivity
import com.musaaji.suite.security.SimAlertActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (PrivacySecurityActivity.isAppLockEnabled(this)) {
            startActivity(Intent(this, AppLockActivity::class.java))
        }

        val modules = listOf(
            ModuleItem(getString(R.string.module_sim_alert), R.drawable.ic_module_generic) {
                startActivity(Intent(this, SimAlertActivity::class.java))
            },
            ModuleItem(getString(R.string.module_photo_pdf), R.drawable.ic_module_generic) {
                startActivity(Intent(this, PhotoPdfEditorActivity::class.java))
            },
            ModuleItem(getString(R.string.module_ocr), R.drawable.ic_module_generic) {
                startActivity(Intent(this, OcrActivity::class.java))
            },
            ModuleItem(getString(R.string.module_excel), R.drawable.ic_module_generic) {
                startActivity(Intent(this, TableToExcelActivity::class.java))
            },
            ModuleItem(getString(R.string.module_ai), R.drawable.ic_module_generic) {
                startActivity(Intent(this, AiAssistantActivity::class.java))
            },
            ModuleItem(getString(R.string.module_privacy), R.drawable.ic_module_generic) {
                startActivity(Intent(this, PrivacySecurityActivity::class.java))
            },
            ModuleItem(getString(R.string.module_about), R.drawable.ic_module_generic) {
                startActivity(Intent(this, AboutActivity::class.java))
            }
        )

        binding.recyclerModules.layoutManager = LinearLayoutManager(this)
        binding.recyclerModules.adapter = ModuleAdapter(modules)
    }
}
