package com.musaaji.distancesimalert

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        showHome()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 20)
    }

    private fun showHome() {
        val r = root()
        r.addView(TextView(this).apply {
            text = "Distance & SIM Alert"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        r.addView(TextView(this).apply {
            text = "GPS Tracking • Distance Alert • SIM Monitor"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        })
        status = TextView(this).apply {
            text = "Tracking: OFF"
            textSize = 19f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        r.addView(status)

        r.addView(Button(this).apply {
            text = "START TRACKING"
            setOnClickListener {
                ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, LocationService::class.java))
                status.text = "Tracking: ON"
            }
        })
        r.addView(Button(this).apply {
            text = "STOP TRACKING"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LocationService::class.java))
                status.text = "Tracking: OFF"
            }
        })
        r.addView(Button(this).apply {
            text = "OPEN MAP"
            setOnClickListener {
                val lat = prefs.getString("last_lat", "")
                val lon = prefs.getString("last_lon", "")
                if (!lat.isNullOrBlank() && !lon.isNullOrBlank()) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
                } else Toast.makeText(this@MainActivity, "No location saved yet", Toast.LENGTH_SHORT).show()
            }
        })
        r.addView(Button(this).apply { text = "SETTINGS"; setOnClickListener { showSettings() } })
        r.addView(Button(this).apply { text = "HISTORY"; setOnClickListener { showHistory() } })
        r.addView(Button(this).apply { text = "CHECK SIM"; setOnClickListener { checkSim() } })

        val last = prefs.getString("last_lat", null)
        val sim = prefs.getString("sim_summary", "Not checked yet")
        r.addView(TextView(this).apply {
            text = "\nLast location: ${last ?: "Not available"}\nSIM monitor: $sim"
            textSize = 14f
        })
        setContentView(r)
    }

    private fun showSettings() {
        val r = root()
        r.addView(TextView(this).apply { text = "Settings"; textSize = 25f })
        val d = EditText(this).apply { hint = "Distance (km)"; inputType = 2 or 8192; setText(prefs.getString("distance", "5")) }
        val p = EditText(this).apply { hint = "Alert phone number"; inputType = 3; setText(prefs.getString("phone", "")) }
        val m = EditText(this).apply { hint = "SMS message"; minLines = 3; setText(prefs.getString("message", "Distance alert from your device.")) }
        r.addView(d); r.addView(p); r.addView(m)
        r.addView(Button(this).apply {
            text = "SAVE"
            setOnClickListener {
                val km = d.text.toString().toDoubleOrNull()
                if (km == null || km <= 0) { d.error = "Enter a distance greater than 0"; return@setOnClickListener }
                prefs.edit().putString("distance", km.toString()).putString("phone", p.text.toString().trim()).putString("message", m.text.toString()).apply()
                Toast.makeText(this@MainActivity, "Settings saved", Toast.LENGTH_SHORT).show()
            }
        })
        r.addView(Button(this).apply { text = "BACK"; setOnClickListener { showHome() } })
        setContentView(r)
    }

    private fun showHistory() {
        val r = root()
        r.addView(TextView(this).apply { text = "Alert History"; textSize = 25f })
        val history = prefs.getString("history", "No alerts yet.")
        r.addView(TextView(this).apply { text = history; textSize = 15f })
        r.addView(Button(this).apply { text = "CLEAR HISTORY"; setOnClickListener { prefs.edit().remove("history").apply(); showHistory() } })
        r.addView(Button(this).apply { text = "BACK"; setOnClickListener { showHome() } })
        setContentView(r)
    }

    private fun checkSim() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionsIfNeeded(); return
        }
        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val current = tm.simState
        val old = prefs.getInt("sim_state", -1)
        val changed = old != -1 && old != current
        val label = when (current) {
            TelephonyManager.SIM_STATE_READY -> "SIM ready"
            TelephonyManager.SIM_STATE_ABSENT -> "SIM absent"
            TelephonyManager.SIM_STATE_PIN_REQUIRED -> "SIM PIN required"
            TelephonyManager.SIM_STATE_PUK_REQUIRED -> "SIM PUK required"
            TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "Network locked"
            else -> "SIM state: $current"
        }
        prefs.edit().putInt("sim_state", current).putString("sim_summary", label).apply()
        Toast.makeText(this, if (changed) "SIM state changed: $label" else "SIM check complete: $label", Toast.LENGTH_LONG).show()
    }

    private fun requestPermissionsIfNeeded() {
        val p = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, p.toTypedArray(), 99)
    }
}
