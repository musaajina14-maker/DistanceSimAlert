package com.musaaji.distancesimalert

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.*
import android.telephony.SmsManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class LocationService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private var startLat: Double? = null
    private var startLon: Double? = null
    private var alertSent = false

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
        startForeground(10, notify("Waiting for GPS…"))
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return

        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000L)
            .setMinUpdateIntervalMillis(5_000L)
            .setWaitForAccurateLocation(false)
            .build()
        fused.requestLocationUpdates(req, cb, Looper.getMainLooper())
    }

    private val cb = object : LocationCallback() {
        override fun onLocationResult(res: LocationResult) {
            val l = res.lastLocation ?: return
            if (startLat == null) { startLat = l.latitude; startLon = l.longitude }
            val km = haversine(startLat!!, startLon!!, l.latitude, l.longitude)
            val p = getSharedPreferences("settings", MODE_PRIVATE)
            p.edit().putString("last_lat", l.latitude.toString()).putString("last_lon", l.longitude.toString()).putFloat("last_accuracy", l.accuracy).apply()
            updateNotification("Tracking active • %.2f km".format(Locale.US, km))

            val target = p.getString("distance", "5")?.toDoubleOrNull() ?: 5.0
            if (!alertSent && km >= target) { alertSent = true; sendSms(l.latitude, l.longitude, km) }
        }
    }

    private fun sendSms(lat: Double, lon: Double, km: Double) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return
        val p = getSharedPreferences("settings", MODE_PRIVATE)
        val phone = p.getString("phone", "")?.trim().orEmpty()
        if (phone.isEmpty()) return
        val address = try {
            Geocoder(this, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()?.getAddressLine(0) ?: "Address unavailable"
        } catch (_: Exception) { "Address unavailable" }
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val custom = p.getString("message", "Distance alert from your device.").orEmpty()
        val sms = "$custom\n\nDistance: %.2f km\nAddress: $address\nCoordinates: %.6f, %.6f\nTime: $time".format(Locale.US, km, lat, lon)
        SmsManager.getDefault().sendTextMessage(phone, null, sms, null, null)
        val old = p.getString("history", "").orEmpty()
        p.edit().putString("history", "$time | %.2f km | $address | $lat,$lon\n$old".format(Locale.US, km)).apply()
    }

    private fun haversine(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371.0
        val x = Math.toRadians(c - a); val y = Math.toRadians(d - b)
        val z = sin(x / 2).pow(2) + cos(Math.toRadians(a)) * cos(Math.toRadians(c)) * sin(y / 2).pow(2)
        return r * 2 * atan2(sqrt(z), sqrt(1 - z))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("distance_alert", "Distance Alert", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notify(t: String): Notification = NotificationCompat.Builder(this, "distance_alert")
        .setContentTitle("Distance & SIM Alert")
        .setContentText(t)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setOngoing(true)
        .build()

    private fun updateNotification(t: String) {
        getSystemService(NotificationManager::class.java).notify(10, notify(t))
    }

    override fun onDestroy() { fused.removeLocationUpdates(cb); super.onDestroy() }
    override fun onBind(i: Intent?) = null
}
