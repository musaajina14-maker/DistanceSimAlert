# Distance & SIM Alert v4
Developer: Musa Aji

V4 continues the V3 Android project and improves foreground GPS tracking, live notification distance updates, input validation, notification permission support, map opening, history, SMS alert content, and SIM-state checking.

Important: SIM-state checking is not the same as guaranteed physical SIM-replacement detection on every Android phone. Device/carrier restrictions may affect what Android exposes.

Build with Android Studio/Gradle on a computer. This package is Android source code, not a ready-made APK.
